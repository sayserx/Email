<?php
session_start();
require '../server/server.php';
require '../register_gmail/register_oop.php';
require 'password_oop.php';

if (isset($_POST["reset"])) {
$password = $_POST["password"];
$password1 = $_POST["password1"];
$password2 = $_POST["password2"];

if ($_SESSION["password"] !== $password) {
	$_SESSION["error"] = "Please enter the correct password";
	header("location: ../reset_password.php");
}

if ($password1 !== $password2) {
	$_SESSION["error"] = "Please enter the correct password and verification code";
	header("location: ../reset_password.php");
}

 else {
	$user = $register->email($conn, $_SESSION["username"], $_SESSION["password"], 'username');
	if (isset($user)) {
        print_r ($user);
        $password_class -> reset_password($conn, $user["id"], $password2);
        $_SESSION["password"] = $password2;
        $_SESSION["success"] = "Reset Password Success";
        header("location: ../profile.php");
    } else {
    	$_SESSION["error"] = "Error Please inform admin";
    	header("location: ../reset_password.php");
    }
}

}