<?php

class password {
	
	function reset_password($conn,$id,$password) {
		mysqli_query($conn, "UPDATE user SET id = '".$id."' , password = '".$password."' ");
	}
	
}
$password_class = new password();