<?php
class upload_cargo {
	
function random() {
        $characters = '09850927263553913111abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randstring = '';
        for ($i = 0; $i < 10; $i++) {
            $random1 = $characters[rand(0, strlen($characters))];
            $random2 = $characters[rand(0, strlen($characters))];
            $random3 = $characters[rand(0, strlen($characters))];
            $random4 = $characters[rand(0, strlen($characters))];
            $random5 = $characters[rand(0, strlen($characters))];
        }
        return "#" . strtoupper($random1 . $random2 . $random3 . $random4 . $random5);
    }
    
}

$upload = new upload_cargo();

?>