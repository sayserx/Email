<?php
require '../server/server.php';
require 'upload_oop.php';
if (isset($_POST["upload"])) {
	
// form post
$name = $_POST["name"];
$num = $_POST["num"];
$text = $_POST["text"];


//image
$image = $_FILES["image"];
$image["name"] = "chaos_image_".rand().".jpg";
$random_file_name = $image["name"];

//file
$filez = $_FILES["file_cargo"];
$file = explode(".", $filez["name"]);
$file_random = "chaos_file_".rand()."." . $file[count($file)-1];


//random pass cargo
$random = $upload->random();

 if (move_uploaded_file($image["tmp_name"], "../image_cargo/".$random_file_name)) {
	if (move_uploaded_file($filez["tmp_name"], "../cargo_back_end/file_cargo/".$file_random)) {
 	
      $query = mysqli_query($conn, "INSERT INTO product (image, name, num, text, cargo, file) VALUES ('$random_file_name', '$name','$num','$text','$random','$file_random')");
      if (!$query) {
      	echo "error: โปรดติดต่อ admin!!!!";
      }
      header("location: ../shop.php");
    }
 }
}