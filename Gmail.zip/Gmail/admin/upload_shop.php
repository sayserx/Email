<?php
require '../server/server.php';
require 'upload_oop.php';
    $query = mysqli_query($conn, "SELECT * FROM product");
    while ($box = mysqli_fetch_array($query)) {
    echo "<pre>";
    
    print_r ($box);
    echo "</pre>";
    }
    
    
    echo $upload->random();
?>
	
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>




<form action="register_shop.php" method="post" enctype="multipart/form-data">
<input name="image" type="file" required>
<input name="name" type="text" placeholder="name" required>
<input name="num" type="text" placeholder="num" required>
<input name="text" type="text" placeholder="text" required>
<input name="file_cargo" type="file" required>
<br>
<button name="upload">upload</button>

</form>

</body>
</html>
