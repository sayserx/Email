<?php
session_start();
require 'server/server.php';

$email = $_SESSION["email"];
$check_select = "SELECT * FROM product";
$check_select_x = "SELECT * FROM deal";
$check_select_query = mysqli_query($conn, $check_select);
$check_select_query_x = mysqli_query($conn, $check_select_x);

if (isset($_SESSION["error"])) {
	echo $_SESSION["error"];
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <meta name="theme-color" content="black">
  <title>shop</title>
</head>
<body>
 
<div class="box-black">
  <marquee direction="left">website chaos auto service system</marquee>
  
  <div class="menu">
    <img src="image_shop/orca-image-1885319496.jpeg">
    <button class="fa fa-search"></button>
  </div>
<div class="search">


</div>
</div>

<div class="top">
    <a href="#"><li style="
    color: #FF5800;
    " class="fa fa-shopping-cart"><p>shop</p></li></a>
      <a href="#"><li class="fa fa-book"><p>use</p></li></a>
      <a href="warn.php"> <li class="fa fa-bell"><p>warn</p></li></a>
      <a href="basket.php"> <li class="fa fa-shopping-basket"><p>basket</p></li></a>
    <a href="profile.php"><li class="fa fa-user-circle"><p>profile</p></li></a>
</div>

<div class="box-shop">
  <p class="x">products you are interested in "cyber security"</p>
</div>

<?php 


	if (!isset($email)) {
		while ($box = mysqli_fetch_array($check_select_query)) {
   	echo '
 <div class="box">
<form action="cargo.php" method="post">
  <div class="box1">
  	<label for="' . $box["id"] . '">
   <img src="image_cargo/' . $box["image"] . '">
   <p class="name">' . $box["name"] . '</p>
    <p class="fa fa-credit-card"> ' .$box["num"] . '</p>
    <button style="display: none;" id="' . $box["id"] . '" name="button" value="'. $box["id"] . '"></button>
    </label>
</div>
</form>
  </div> '; 
  }
} else {
	// join
} 
	
	
	
	//
				/*
 <div class="box">
<form action="cargo.php" method="post">
  <div class="box1">
  	<label for="' . $box["id"] . '">
   <img src="image_cargo/' . $box["image"] . '">
   <p class="name">' . $box["name"] . '</p>
    <p class="fa fa-credit-card"> ' .$box["num"] . '</p>
    <button style="display: none;" id="' . $box["id"] . '" name="button" value="'. $box["id"] . '"></button>
    </label>
</div>
</form>
  </div> '; 
  */
				
			/*
			echo '
 <div class="box">
<form action="cargo.php" method="post">
  <div class="box1">
  	<label for="' . $box["id"] . '">
   <img src="image_cargo/' . $box["image"] . '">
   <p class="name">' . $box["name"] . '</p>
    <p class="fa fa-credit-card"> ' .$box["num"] . '</p>
    <button style="display: none;" id="' . $box["id"] . '" name="button" value="'. $box["id"] . '"></button>
    </label>
</div>
</form>
  </div> '; 
  */
		//} 
	




/*
while ($box = mysqli_fetch_array($check_select_query)) {
   	echo '
 <div class="box">
<form action="cargo.php" method="post">
  <div class="box1">
  	<label for="' . $box["id"] . '">
   <img src="image_cargo/' . $box["image"] . '">
   <p class="name">' . $box["name"] . '</p>
    <p class="fa fa-credit-card"> ' .$box["num"] . '</p>
    <button style="display: none;" id="' . $box["id"] . '" name="button" value="'. $box["id"] . '"></button>
    </label>
</div>
</form>
  </div> '; 
*/

/*echo "<pre>";
   	print_r ($box);
       echo "</pre>";
*/
       
   
	


?>
  	
<div class="box-x">
  <br>
<p class="menx">product my shop</p>
<p>
  The products of the web chaos shop are about <br> <li>gaming</li><li>cybersecurity</li>
   <li>websites</li><li>other</li></p>
</div>

<br>
<div class="foll">
  <p class="logo">Gaming</p>
  <p class="notx">There are no products about "gameing"  yet</p>
</div>

<div class="foll">
   <p class="logo">cyber security</p>
   <p class="notx">There are no products about "cyber security" yet</p>
</div>

<div class="foll">
     <p class="logo">website</p>
  <div class="box1">
         <img src="image_shop/20221007_214131.jpg">
         <p class="name">Tool💀</p>
         <p class="fa fa-credit-card"> 150</p>
       </div>
</div>

<br>
<div class="foll">
     <p class="logo">other</p>
     <p class="notx">There are no products about "other" yet</p>
</div>


<br><br><p></p><br><br>

<style>

.box1 {
  float: left;
  display: block;
  margin-left: 12px;
  width: 180px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  border-radius: 5px;
  margin-top: 10px;
}

.box1 p {
  margin-left: 10px;
}

.box1 .name {
  font-weight: 900;
  font-size: 15px;
}

.foll .logo {
  font-size: 15px;
  margin-left: 10px;
  font-weight: 900;
}

.foll {
  clear: both;
  padding-top: 10px;
}

.foll .notx {
  color: #FF6262;
}

.foll p {
  margin-left: 10px;
}

.box-x {
  clear: both;
  margin-left: 10px;
}

.box-x .menx {
  font-weight: 900;
  font-size: 20px;
}

body {
     font-family: Arial, Helvetica, sans-serif;
}
  .top {
    color: #FFFFFF;
    position:fixed;
    left:0px;
    bottom:0px;
    width: 100%;
    background: white;
    padding-top: 10px;
    display: flex;
    justify-content: space-around;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  }
  
.top li:hover {
  color: #FF5800;
}
 .top p {
  padding-left: 20px;
  color: #646465;
  margin: auto;
  text-align: center;
  padding: 20px;
  font-size: 20px;
}
.top li {
  color: #333434;
  margin: auto;
  text-align: center;
  font-size: 30px;
}
.search {
  display: flex;
  justify-content: space-around;
  background: black;
  padding: 10px;
}

.search input {
  padding: 10px;
  width: 87%;
}

.search button {
  padding: 13px;
  background: #000000;
  border: 2px solid #414141;
  color: white;
  
}

  .search .x{
    color: #F8F8F8;
  }
  
  
  .menu img {
    height: 70px;
    margin-top: -5px;
  }
  
  .menu button {
    background: none;
    color: white;
    font-size: 20px;
    border: none;
    border-radius: 10px;
    float: right;
    padding: 25px;
    margin-top: 5px;
  }
  
  .box-shop .x {
    padding: 10px;
    font-size: 17px;
  }

  .box1 img {
    height: 200px;
    width: 180px;
    border-top-left-radius: 5px;
  }
  
  .box-black {
    background: black;
  }
  
  marquee {
    background: black;
    color: #FFFFFF;
    border-bottom: 1px solid #414141;
  }
  
   @media screen and (max-width: 400px) {
  .top p {
    font-size: 15px;
  }
  
  .top li {
    font-size: 25px;
  }
  .search .x {
    display: none;
  }
  
 }
</style>

</body>
</html>
