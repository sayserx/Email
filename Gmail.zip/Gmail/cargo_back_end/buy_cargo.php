<?php
session_start();
require '../server/server.php';
require 'buy_cargo_oop.php';

if (!isset($_SESSION["username"])) {
	echo '<script>alert("สมัครสมาชิกก่อนเหอะ")</script>';
	echo "<script>location.replace('../shop.php');</script>";
}
?>


<!DOCTYPE html>
<html>
<head>
<title>Font Awesome Icons</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="sleep">
<ul style="text-align: center" class="fa-ul">
  <li><i style="font-size: 25px; " class="fa-li fa fa-spinner fa-spin"></i>
</ul>
</div>
<div style="text-align: center">
  <br>
  <br>
  <p>โปรดรอสักครู่</p>
  
</div>


<style>
  .sleep {
    margin-left: 48%;
    margin-top: 70%;
  }
</style>
</body>
</html>
<?php

if (isset($_POST["buy"])) {
$buy_database = $cargo->select_cargo($conn,$_POST["buy"]);
$money = $_SESSION["money"];
$buy_cargo = $buy_database["num"];
$day = date("d/m/o");

     //cargo -.- 
	if ($money > $buy_cargo OR $money === $buy_cargo) {
		$QRcode = $buy_database["cargo"];
		$sql = $cargo->select_cargo_repeat($conn, $QRcode);
		if (mysqli_num_rows($sql) === 0) {
			$_SESSION["cargo_image"] = $buy_database["image"];
	        $_SESSION["cargo_name"] = $buy_database["name"];
	        $_SESSION["cargo_num"] = $buy_database["num"];
	        $_SESSION["cargo_text"] = $buy_database["text"];
	        $_SESSION["cargo_pass"] = $buy_database["cargo"];
	        $_SESSION["cargo_file"] = $buy_database["file"];
	        $_SESSION["cargo_day"] = $day;
	        $_SESSION["cargo_time"] = date("h")+6 . ":" . date("i");
	        $_SESSION["cargo_money"] = $money-$_SESSION["cargo_num"];
	        $cargo_x_u = $buy_database["cargo"];
	        mysqli_query($conn, "UPDATE product SET stock = stock-1 where cargo = '$cargo_x_u' ");
	        $cargo->up_cargo($conn,$_SESSION["cargo_image"],$_SESSION["cargo_name"],$_SESSION["cargo_pass"],$_SESSION["cargo_time"],$_SESSION["cargo_day"],$_SESSION["cargo_num"],$_SESSION["cargo_file"],$_SESSION["cargo_text"],$_SESSION["cargo_money"],$_SESSION["email"]);
	        header("location: ../mycargo.php"); 
			} else {
				 $_SESSION["error"] = "สินค้าซํ้าโปรดซื้อของสินค้าอื่น";
			     echo "<script>location.replace('../shop.php');</script>";
				}
	} else { 
		if ($money <  $buy_cargo) {
			  $_SESSION["error"] = "เงินไม่พอ กรุณาเติมเงิน";
			  echo "<script>location.replace('../shop.php');</script>";
			} else {
				$_SESSION["error"] = "เกิดข้อผิดพลาดทางระบบ กรุณาเเจ้งเเอดมิน";
				echo "<script>location.replace('../shop.php');</script>";
			}
	}
} else if (isset($_SESSION["select"])) {
	    $buy_database = $cargo->select_cargo_deal($conn,$_SESSION["select"]);
	    echo "<pre>";
	    print_r ($buy_database);
	     echo "</pre>";
	     $_SESSION["cargo_image"] = $buy_database["image"];
	     $_SESSION["cargo_name"] = $buy_database["cargo"];
	     $_SESSION["cargo_num"] = $buy_database["money"];
	     $_SESSION["cargo_text"] = $buy_database["text"];
	     $_SESSION["cargo_pass"] = $buy_database["pass_cargo"];
	     $_SESSION["cargo_file"] = $buy_database["file"];
	     $_SESSION["cargo_day"] = $buy_database["day"];
	     $_SESSION["cargo_time"] = $buy_database["time"];
	     $_SESSION["cargo_money"] = $buy_database["money_set"];
	     header("location: ../mycargo.php");
} else {
	$_SESSION["error"] = "เกิดข้อผิดพลาดทางระบบ กรุณาเเจ้งเเอดมิน (select_cargo_deal)!! ";
	echo "<script>location.replace('../shop.php');</script>";
}
?>