<?php


class cargo_setting {


function select_cargo($conn, $id) {
	$sql = mysqli_query($conn, "SELECT * FROM product where id='$id' ");
	return mysqli_fetch_array($sql);
}

function select_cargo_deal($conn, $id) {
	$sql = mysqli_query($conn, "SELECT * FROM deal where id='$id' ");
	return mysqli_fetch_array($sql);
}

function select_cargo_repeat($conn, $QRcargo) {
    $sql = mysqli_query($conn, "SELECT * FROM deal where pass_cargo = '$QRcargo' ");
    return $sql;
}

function delete_cargo($conn, $table, $table_id ,$cargo) {
	$sql = mysqli_query($conn, "DELETE FROM $table WHERE $table_id='$cargo' ");
}



function up_cargo($conn,
$image,
$cargo,
$pass_cargo,
$time, 
$day, 
$money, 
$file, 
$text, 
$money_x,
$user_cargo
) {
	$sql = mysqli_query($conn, "INSERT INTO deal (image, cargo, pass_cargo, time, day, money, file, text, money_set, user_cargo) VALUES ('$image', '$cargo', '$pass_cargo', 'time', '$day', '$money', '$file', '$text', '$money_x', '$user_cargo')");
	$update = mysqli_query($conn, "UPDATE user SET money='$money_x' WHERE email = '$user_cargo' ");
	$_SESSION["money"] = $money_x;
}

}
$cargo = new cargo_setting();
?>