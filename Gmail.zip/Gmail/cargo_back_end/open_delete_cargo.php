<?php
require '../server/server.php';
require 'buy_cargo_oop.php';
session_start ();

if (isset($_POST["delete"])) {
	$_SESSION["success"] = "Successfully deleted the cargo";
    $cargo->delete_cargo($conn, "deal", "pass_cargo", $_POST["delete"]);
    echo "<script>location.replace('../profile.php');</script>";
}

if (isset($_POST["open"])) {
	$_SESSION["select"] = $_POST["open"];
    echo "<script>location.replace('buy_cargo.php');</script>";
}


?>