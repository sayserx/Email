import java.util.Scanner;

public class number {
    
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in); 
        System.out.print("number: "); 
        int number = myObj.nextInt();
        for (int i=0; i<=12; i++) {
            int unx = number*i;
            System.out.println(number+" × "+i+" = "+unx); 
        }
    }
    
}
