<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title></title>
</head>
<body>

<div class="menu">
   <a href="profile.php" style="float: left; font-size: 20px; padding-left: 5px; color: white; text-decoration: none" class="fa fa-arrow-left"></a>
 <center>
<p class="fa fa-key"> reset password</p>
</center>
</div>

<div class="reset_password">
 <form action="/password/password.php" method="post">
  <img class="image" src="image_shop/password.jpeg">
  <br>
  <p id="logo" class="fa fa-key"> Reset password</p>

  <?php
  	if (isset($_SESSION["error"])) {
      echo ' <br><br><p class="error">' . $_SESSION["error"] . '</p><br>';
      unset($_SESSION["error"]);
      }
   ?>
  <br><br>
  <p id="password" class="fa fa-key"> password</p>
  <br>
  <input type="password" name="password" id="password1" placeholder="password" required>
  <br>
  <br>
  <p id="password" class="fa fa-key"> password new</p>
  <br>
  <input type="password" name="password1" id="password2" placeholder="new password" required>
  <br>
  <br>
  <p id="password" class="fa fa-key"> confirmation password</p>
  <br>
  <input type="password" name="password2" id="password3" placeholder="new password" required>
  <br>
  <p style="font-weight: 900;color: #575858"><input style="width: 20px; margin-left: -240px; margin-top: 10px;" type="checkbox" onclick="show_password()">Show password</p>
  <br>
  <button name="reset"  class="fa fa-key"> Reset password</button>
 </form>
</div>


<style>

body {
  font-family: Arial, Helvetica, sans-serif;
}
 
* {
  margin: 0;
}

  .menu {
    background: black;
    color: white;
    padding: 10px; 
    font-size: 20px;
  }
  
  .reset_password {
    padding: 10px;
    margin: auto;
    text-align: center;
    margin-top: 50%;
  }
  
  .reset_password input {
    background: #F5F5F5;
    width: 350px;
    padding: 10px;
    border: 2px solid #F5F5F5;
    outline: none;
  }
  
  .reset_password input:hover {
    border-bottom: 2px solid black;
  }
  
  .reset_password button {
    background: #A4A4A4;
    color: white;
    width: 375px;
    padding: 10px;
    border: 2px solid #A4A4A4;
  }
  
  .reset_password button:hover {
  	background: black;
      border: 2px solid  black;
  }
  
  .image {
    height: 50%;
    width: 50%;
    border-radius: 5px;
    float: left;
  }
  
  .reset_password #password {
   width: 370px;
   margin: auto;
   text-align: left;
   color: #303030;
  }
  
  .error {
    background: #FF5151;
    padding: 10px;
    color: white;
    text-align: center;
    border: 2px solid #FF3434;
    font-weight: 900;
    font-size: 15px;
    border-radius: 5px;
    width: 370px;
    float: right;
    margin-right: 40px;
  }
  
  #logo {
    font-weight: 900;
    color: #1D1D1D;
    float: left;
    margin-left: 50px;
    font-size: 18px;
  }
  
  @media screen and (max-width: 400px) {
    .image {
      float: none;
    }
    
    .error {
      width: 350px;
      font-size: 15px;
      margin-right: 0px;
    }
    
    #logo {
      float: none;
      margin-left: 0px;
    }
    
  }
  
</style>


<script>
  function show_password() {
    var password = document.getElementById("password1");
    var password1 = document.getElementById("password2");
    var password2 = document.getElementById("password3");
    if (password.type === "password") {
       password.type = "text";
       password1.type = "text";
       password2.type = "text";
    } else {
       password.type = "password";
       password1.type = "password";
       password2.type = "password";
    }
  }
</script>


</body>
</html>
