<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <title>login in chaos-shop</title>
</head>
<body>
  
  <div class="box-x">
<form action="register_gmail/login.php" method="post">
  <div class="icon">
  <img src="image_shop/chaos.jpeg">
  <p>Anarchist Federation Chaos</p>
  </div>
  <div class="box">
     <p style="
     font-weight: 900;
     font-size: 20px;
     ">Login in website</p>
     <br>
     	
     <?php
 if (isset($_SESSION["error"])) {
 echo '<p id="error">' . $_SESSION["error"] . '</p><br>';
 unset ($_SESSION["error"]);
 } 
?>
	
    <p class="fa fa-user"> username and email</p>
    <br>
    <input type="text" name="username" placeholder="username and email" required>
    <br>
  <p class="fa fa-key"> password</p><p></p>
  <input type="password" name="password" placeholder="password" required>
  <br>
  <p class="fa fa-key"> Password Confirm</p><p></p>
   <input type="password" name="password2" placeholder="Password Confirm" required>
   <br>
   <br>
   <br>
   <div class="g-recaptcha" data-callback="capcha_shop" data-sitekey="6LcncPUiAAAAACNNtvzcWMVbzrgNK0-mycL98kde"></div>
   <br>
   <button type="submit" id="login" name="button_login" disabled>login</button>
   <br>
  <p class="font">You are not registered yet? <a href="register.php">register</a>
  <p class="font">want to go back to the shop <a href="index.php">shop</a>
 
  </div>
</form>
</div>
<style>
* {
  margin: 0;
  
}
body {
   font-family: Arial, Helvetica, sans-serif;
   position: absolute;
   top: 50%;
   width: 100%;
}
  .box {
   float: right;
   padding: 10px;
   border-radius: 10px;
  }
 img {
   height: 300px;
   width: 300px;
   border-radius: 10px;
 }
 .icon {
   text-align: center;
   margin-left: 10%;
   position: absolute;
   padding: 10px;
   float: left;
   border-radius: 10px;
 }
 
 .icon p {
   font-weight: 900;
   font-size: 20px;
   color: #767676;
 }
 
 #error {
    background: #FF5151;
    padding: 10px;
    color: white;
    text-align: center;
    border: 2px solid #FF3434;
    font-weight: 900;
    font-size: 15px;
    border-radius: 5px;
    width: 350px;
  }
  
 .box input {
   background: #FAFCFA;
   border: 2px solid #FFFFFF;
   padding: 10px;
   width: 400px;
   transition-duration: 1.5s;
   outline: none;
   float: left;
 }
 .box input:hover {
   background: #E7FAFF;
   border-bottom: 1px solid #000000;
 }
 .box p {
 text-align: left;
 color: #535353;
 }
 
 .box button {
   background: #B7B7B7;
   width: 425px;
   padding: 10px;
   color: #FFFFFF;
   border: 2px solid #B7B7B7;
   transition-duration: 1.5s;
 }

 .box a {
   color: #00D5FF;
 }
 
  @media screen and (max-width: 400px) {
    
    img {
      width: 150px;
      height: 150px;
    }
    .icon { 
      box-shadow: none;
      position: relative;
      margin-left: 25%;
      padding: 10px;
      margin-top: -170px;
    }
    
   .box p {
    
   }
    .box {
      float: none;
    }
    .box .font {
      float: left;
    }
     .icon p {
       display: none;
     }
     .box input {
       width: 90%;
     }
     .box button {
       width: 97%;
     }
     .box p {
       text-align: center;
    }
  }
</style>

<script>
function capcha_shop() {
	document.getElementById('login').disabled = false; 
	document.getElementById('login').style = "background: #000000;border: 2px solid #000000;";
}
</script> 

</body>
</html>
