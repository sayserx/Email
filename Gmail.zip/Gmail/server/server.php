<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register_login_database";

$conn = mysqli_connect($servername, $username, $password, $dbname);

 if (!$conn) {
        die("เกิดข้อผิดพลาด: " . mysqli_connect_error());
}
