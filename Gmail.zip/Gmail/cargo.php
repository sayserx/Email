<?php
session_start();
require 'server/server.php';

$button = $_POST["button"];
if (!isset($button)) {
	header("location: ../shop.php");
}

$sql = "SELECT * FROM product WHERE id = '$button'";
$sql_run = mysqli_query($conn, $sql);
$sql_put = mysqli_fetch_array($sql_run);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <title></title>
</head>
<body>

<div class="menu">
  <a href="shop.php" style="color: white; text-decoration: none;" id="left" class="fa fa-angle-left"></a>
  <p id="center">Product Details</p>
</div>
<header>
  <img id="image_shop" src="<?php echo "image_cargo/" . $sql_put["image"]; ?>">
  <button id="backleft" onclick="off_number()" class="fa fa-caret-square-o-left"></button>
  <button id="backrint" onclick="on_number()" class="fa fa-caret-square-o-right"></button>
  <p id="number_x"></p>
</header>


<div class="basgetx">
<br><br>
<h1 style="color: red; padding-left: 10px"> $ <?php echo $sql_put["num"]; ?></h1>
<br>
<h1 style="font-size: 20px; padding-left: 10px"><?php echo $sql_put["name"]; ?> </h1>
<p class="getx">Not description</p>
<br>

<div class="logo">
  <img style="height: 45px; border-radius: 150px; float: left" src="image_shop/chaos.jpeg">

  <p style="margin-top: 15px; margin-left: 5px; float: left; font-size: 20px;"> Chaos Shop</p>
  <p style="float: right; font-size: 15px; padding: 15px; padding-left: 100px" class="fa fa-arrow-right"></p>
  <br style="clear: both">
    <input style="display: none" type="text" id="number" value="1">
</div>
<br>
<button class="fa fa-sort-desc" style="padding: 10px; font-weight: 900; background: none; border: none; font-size: 20px" onclick="off()"> Details/more</button>
<br>
<div id="show" class="show" style="display: block">
  <li><?php echo $sql_put["text"]; ?></li>
 </div>
</div>
<br><br><br>
<div class="top">
	<?php 
	if (isset($_SESSION["username"])) {
        echo '<form action="cargo_back_end/buy_cargo.php" method="post"><button id="buy" class="fas fa-cart-arrow-down" name="buy" value="' . $sql_put["id"] . '"> Buy</button></form>
       <form action="cargo_back_end/buy_cargo.php" method="post"><button id="buy" class="fas fa-shopping-basket" style="width: auto; background: #E17305; border: 2px solid #E17305;"> Add Basket</button></form>';
} else {
	echo '<button id="log" onclick="log()" class="fas fa-sign-in-alt"> Please login before use</button>';
}
?>
</div>

<style>

  body {
    font-family: Arial, Helvetica, sans-serif;
  }
  
  * {
    margin: 0;
  }

  header img{
    height: 533px;
    width: 400px;
  }
  
  #buy {
    background: #06CB22;
    color: white;
    width: 250px;
    padding: 10px;
    border: 2px solid #06CB22;
    font-weight: 900; 
    float: left;
  }
  
    #log {
    background: #FD7F5E;
    color: white;
    width: 380px;
    padding: 15px;
    border: 1px solid #FF6F57;
    font-weight: 900;
    font-size: 15px;
  }
  
  #backleft {
   position: absolute;
   margin-top: 220px;
   margin-left: -370px;
   font-size: 40px;
   color: white;
   background: none;
   border: none;
  }
  
  
  #backrint {
   position: absolute;
   margin-top: 220px;
   margin-left: -50px;
   font-size: 40px;
   color: white;
   background: none;
   border: none;
  }
  
  .logo {
    border: 1px solid #CECECE;
    padding: 10px;
  }

  .show {
    font-size: 15px;
    padding: 10px;
  }
  
  #number_x {
    font-weight: 900;
    font-size: 20px;
    margin-top: -45px;
    color: white;
    margin-left: 10px;
  }
  
  .top {
    position:fixed;
    left:0px;
    bottom:0px;
    width: 100%;
    background: white;
    padding: 10px;
    border-top: 1px solid #CECECE;
  }
  
  .getx {
    font-size: 15px;
    color: #747474;
    margin-left: 10px;
  }
  
  #show {
    transition-duration: 1.5s;
  }
  
  .menu {
    background: black;
    color: white;
    padding: 15px;
  }
  
  .menu #left {
    float: left;
    font-size: 25px;
    margin-top: -2px;
  }
  
  .menu #center {
    text-align: center;
    font-size: 20px;
    font-weight: 900;
  }
  

</style>

<script>
var array1 = ["","<?php echo $sql_put["image"]; ?>"];
var num_array = (array1.length-1);
document.getElementById("number_x").innerHTML = 1+"/"+num_array;


function on_number() {
  var number = document.getElementById("number").value;
  console.log (number)
 if (number < num_array) {
    number++;
    var xo = document.getElementById("number").value = number;
    document.getElementById("number_x").innerHTML = xo+"/"+num_array;
    document.getElementById("image_shop").src = array1[xo];
      
   }
   
}

function log() {
	Swal.fire({
    icon: 'error',
    title: 'Error',
    text: 'Please login before use',
    footer: '<a style="color: #57B6FF; text-decoration: none;" href="login.php">Press to login !!</a>'
  })
}


function off_number() {
  var number = document.getElementById("number").value;
  if (1 < number) {
      number--;
      var ox = document.getElementById("number").value = number;
      document.getElementById("number_x").innerHTML = ox+"/"+num_array;
 document.getElementById("image_shop").src = array1[ox];
  }
}

function off() {
  var x = document.getElementById("show").style.display;
  if (x === "none") {
    document.getElementById("show").style.display = "block";
  } else {
    document.getElementById("show").style.display = "none";
  }
}
</script>

</body>
</html>
