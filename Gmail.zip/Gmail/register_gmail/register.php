<?php
session_start();
require 'register_oop.php';
require '../server/server.php';

if (isset($_POST["button_register"])) {
	$username = mysqli_real_escape_string($conn, $_POST["username"]);
	$email = mysqli_real_escape_string($conn, $_POST["email"]);
	$password = mysqli_real_escape_string($conn, $_POST["password"]);
	$password2 = mysqli_real_escape_string($conn, $_POST["password_2"]);
	
	if ($password !== $password2) {
	 $_SESSION["error"] = "รหัสกับรหัสยืนยันไม่ตรงกัน";
     header("location: ../register.php");
     
     } else {
	$result = $register->sql($conn, $username, $email);
    if ($result["username"] === $username) {
	    $_SESSION["error"] = "ชื่อผู้ใช้ ตรงกัน โปรดใช้ชื่อผู้ใช้อื่น";
	    header("location: ../register.php");
    }
   if ($result["email"] === $email) {
	    $_SESSION["error"] = "อีเมล์ตรงกัน โปรดใช้อีเมล์อื่น";
	    header("location: ../register.php");
   } else {
   	if ($result["username"] !== $username) {
    $_SESSION["session_username"] = $username;
    $_SESSION["session_image"] = $register->random_image_profile();
    $_SESSION["session_email"] = $email;
    $_SESSION["session_password"] = $password;
    $_SESSION["session_money"] = 0;
	$_SESSION["otp"] = $register->gmail($email);
	$_SESSION["otp_num"] = 2;
	header("location: ../register_otp.php");
	    }
	  }
	}
	
	
}