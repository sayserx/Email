<?php
session_start();
require 'register_oop.php';
require '../server/server.php';

if (isset($_POST["send_email"])) {
	$input_otp = $_POST["otp_email"];
	
	if ($input_otp === ''.$_SESSION["otp"].'') {
		$_SESSION["image"] = $_SESSION["session_image"];
		$_SESSION["username"] = $_SESSION["session_username"];
        $_SESSION["email"] = $_SESSION["session_email"];
        $_SESSION["password"] = $_SESSION["session_password"];
        $_SESSION["money"] = $_SESSION["session_money"];
        $register->sql_info(
$conn, 
$_SESSION["image"],
$_SESSION["username"], 
$_SESSION["email"],
$_SESSION["password"],
$_SESSION["money"]
);
	    header("location: ../shop.php");
		} else {
			$_SESSION["error"] = "error otp";
			header("location: ../register_otp.php");
		}
}

if (isset($_POST["get_otp"])) {
	if ($_SESSION["otp_num"] < 1) { 
		$_SESSION["error"] = "error send";
		} else {
	$_SESSION["otp"] = $register->gmail($_SESSION["session_email"]);
	$_SESSION["otp_num"] = $_SESSION["otp_num"]-1;
	header("location: ../register_otp.php");
	}
}

?>