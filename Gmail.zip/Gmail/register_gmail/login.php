<?php
session_start();
require '../server/server.php';
require 'register_oop.php';


if (isset($_POST["button_login"])) {
$username = mysqli_real_escape_string($conn, $_POST["username"]);
$password = mysqli_real_escape_string($conn, $_POST["password"]);
$password2 = mysqli_real_escape_string($conn, $_POST["password2"]);

if ($password !== $password2) {
	$_SESSION["error"] = "error password and password2";
	header("location: ../login.php");
} else {
	$result = $register->email($conn, $username, $password, "username");
    if (isset($result)) {
        $register->session($result["image_path"], $result["username"], $result["email"], $result["password"], $result["money"]);
        header("location: ../shop.php");
    } else {
    	$result = $register->email($conn, $username, $password, "email");
        if (isset($result)) {
        $register->session($result["image_path"], $result["username"], $result["email"], $result["password"], $result["money"]);
        header("location: ../shop.php");
        } else {
        	$_SESSION["error"] = "error username && email and password";
	        header("location: ../login.php");
        }
    }
  }
}