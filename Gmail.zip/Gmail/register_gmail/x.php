<?php
$image = "x";

if ($image === "y") {
      echo "x";
} else {
	$image = "x";
	echo "y";
}

//echo $image;
//header('Location: ../register.php');

?>