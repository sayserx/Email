<?php

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


class register_email {
	
function gmail($email) {
$mail = new PHPMailer(true);                            
$mail->isSMTP();                                     
$mail->Host = 'smtp.gmail.com';                      
$mail->SMTPAuth = true;                          
$mail->Username = 'chaosxshop@gmail.com';     
$mail->Password = 'qaqwjunxdgqqvhle';             
$mail->SMTPOptions = array(
            'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
            )
        );                         
$mail->SMTPSecure = 'ssl';                           
$mail->Port = 465;                                  
$mail->setFrom('chaosxshop@gmail.com');
$mail->addAddress($email);             
$mail->addReplyTo('chaosxshop@gmail.com');
$mail->isHTML(true);                    
$random_number = rand(10,100000);
$body='<html><head><meta charset="UTF-8"><title></title></head><body> OTP YOUR ' . $random_number . '<br> OTP ของคุณ ' . $random_number . '</body></html>';
$mail->Subject = "chaos";
$mail->Body = $body;
$mail->send();
return $random_number;
 }
 
function sql($conn, $username, $email) {
	$query = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' OR email = '$email' LIMIT 1");
    $result = mysqli_fetch_assoc($query);
    return $result;
}
    
function sql_info($conn, $image, $username, $email, $password, $money) {
	$query = mysqli_query($conn, "INSERT INTO user (image_path, username, email, password, money) VALUES ('$image', '$username', '$email', '$password','$money')");
	$result = mysqli_fetch_assoc($query);
}

function random_image_profile() {
	$image_profile = array("image_go.jpeg","image_hacker.jpeg","image_hacker2.png");
	$random = array_rand($image_profile,1);
	return '../profile_chaos_image/'.$image_profile[$random];
}

function session($image, $username, $email, $password, $money) {
	$_SESSION["image"] = $image;
    $_SESSION["username"] = $username;
    $_SESSION["email"] = $email;
    $_SESSION["password"] = $password;
    $_SESSION["money"] = $money;
}

function email($conn, $username, $password, $type) {
	$username_password = "SELECT * FROM user WHERE " . $type . "= '$username' AND password = '$password'";
	$query = mysqli_query($conn, $username_password);
    $result = mysqli_fetch_assoc($query);
    return $result;
}


}

$register = new register_email();
