<?php 

session_start();
require 'server/server.php';
$email = $_SESSION["email"];


$sql_run = mysqli_query($conn, "SELECT * FROM deal");

if (isset($_POST["logout"])) {
	unset($_SESSION["username"]);
	unset($_SESSION["money"]);
	unset($_SESSION["image"]);
	unset($_SESSION["password"]);
    unset($_SESSION["email"]);
}

?>
	
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" />
   <link rel="stylesheet" href="https://fengyuanchen.github.io/cropperjs/css/cropper.css" />
   <script src="https://fengyuanchen.github.io/cropperjs/js/cropper.js"></script>
   <meta name="theme-color" content="black">
  <title>chaos shop</title>
</head>
<body>

  <div class="modal_fade" id="uploadimage" style='display: none; margin-top: 20%; margin-left: 3%'>
    <p style="float: left; font-size: 20px; font-weight: 900; padding: 10px; border-bottom: 4px solid black;">PROFILE</p>
    <button style="background: none; border: none; text-align: right; font-size: 30px; float: right; width: 40%;
           " class="fa fa-times" onclick="exit_profile()"></button>
           <br>
           <br>
           <br>
    <div class="card-body">
      <div id="image_demo" style="width: 360px"></div>
      <div id="uploaded_image" style="width: 360px;"></div>
    </div>
    <div style="margin: auto; text-align: center" class="card-footer text-muted">
      <button style="padding: 10px; background: #4DDE5F; border: 2px solid #4DDE5F; color: white; font-size: 15px; font-weight: 900;" class="crop_image">update profile</button>
            <button style="padding: 10px; background: #FF2D2D; border: 2px solid #FF2D2D; color: white; font-size: 15px; font-weight: 900;" onclick="exit_profile()">cancel</button>
      
    </div>
  </div>
</div>

<!-- archive -->
<div style="display: none;" id="cargo" class="cargo">
   <button style="background: none; border: none; text-align: right; font-size: 30px; float: right;
       " class="fa fa-times" onclick="cargo()"></button>
  <p id="logo" class="fa fa-archive"> archive</p>
  <br>
  <br>
  <div class="show_archive">
  <p> Image </p>
  <p> Cargo</p>
  <p> Code</p>
  <p> Action</p>
  </div>
  <br>
  <div style="overflow: scroll; height: 270px; width: 400px;">
  	<?php
  $box_none = mysqli_fetch_array($sql_run);
  if (!isset($box_none)) {
	  echo '<p style="margin-top: 20%; margin-left: 5%; font-size: 15px; color: #2D2D2D"> There are no products yet !!
 To make a purchase, see <a style="color: #009CFF" href="">shop...</a></p>';
} else { 
   if ($box_none["user_cargo"] === $_SESSION["email"]) {
	echo '
	<div class="boxio">
 <img src="image_cargo/' . $box_none["image"] . '">
 <p></p>
 <p class="boxio_name">' . $box_none["cargo"] . '</p> 
 <p class="boxio_pass">' . $box_none["pass_cargo"] . '</p>
 <p></p><p></p>
 <form action="cargo_back_end/open_delete_cargo.php" method="post">
 <button id="archive" class="fa fa-archive" value="' . $box_none["id"] . '"  name="open"></button>
 <button id="set" class="fa fa-trash" value="' . $box_none["pass_cargo"] . '" name="delete"></button>
 </form>
 <br><br>
 </div><br>
';
  }
}

 while ($box = mysqli_fetch_array($sql_run)) {
 	if ($box["user_cargo"] === $email) {
 	   echo '
	<div class="boxio">
 <img src="image_cargo/' . $box["image"] . '">
 <p></p>
 <p class="boxio_name">' . $box["cargo"] . '</p> 
 <p class="boxio_pass">' . $box["pass_cargo"] . '</p>
 <p></p><p></p>
 <form action="cargo_back_end/open_delete_cargo.php" method="post">
 <button id="archive" class="fa fa-archive" value="' . $box["id"] . '"  name="open"></button>
 <button id="set" class="fa fa-trash" value="' . $box["pass_cargo"] . '" name="delete"></button>
 </form>
 <br><br>
 </div><br>
'; 
   }
}



 ?>
 	
</div>
</div> 

<div class="profile">
<a class="fa fa-user"> Profile </a>
<?php if (isset($_SESSION["money"])) { echo '<p style="float: right;font-weight: 900;" class="fa fa-btc"> ' . $_SESSION["money"] . '</p>'; } ?>
</div>

<?php

if (isset($_SESSION["error"])) {
    echo '<p class="error">'. $_SESSION["error"] . '</p>';
    unset($_SESSION["error"]);
}

if (isset($_SESSION["success"])) {
    echo '<p class="success">' . $_SESSION["success"] . '</p>';
    unset($_SESSION["success"]);
}

?>

<div class="box">
  <div class="profile_xy">
  <p id="user" style="border-bottom: 2px solid black; padding: 10px;" class="fa fa-user-circle-o"> </p>
  <br>
  <?php
 if (isset($_SESSION["image"])) { 
 echo '<img src=" '. $_SESSION["image"] . '">';
 } else {
echo '<img src="image_shop/profile.png">';
 } 

?>
  
  <?php
  
  if (isset($_SESSION["username"])) {
  echo '
  <p class="user">' . $_SESSION["username"] . '</p>
  <p> ' . $_SESSION["email"] . '</p>
  ';
  } else {
  	echo '
<p class="user"> user</p>
<p> Users who are not logged in!!</p>
';
  }
  ?>
  <br>
  </div>




<!-- box_user -->
<div style="display: none;" class="box_user" id="box_user">
  <button style="background: none; border: none; text-align: right; font-size: 30px; float: right; width: 40%;
     " class="fa fa-times" onclick="box_user()"></button>
    <p id="box_user_p" style="text-align: left; float: left; font-size: 20px; padding: 10px" class="fa fa-vcard"> User Information</p>
  <br style="clear: both;"><br>
  <img style="border-radius: 150px; height: 200px; width: 200px; margin-left: 50px" src='<?php echo $_SESSION["image"] ?>'>
  <br>
  <br>
  <p class="br"></p>
  <br>
  <p class="fa fa-user"> <?php echo $_SESSION["username"] ?></p>
  <br>
  <br>
  <p class="fa fa-envelope"> <?php echo $_SESSION["email"] ?></p>
  <br>
  <br>
  <p class="fa fa-btc"> <?php echo $_SESSION["money"] ?></p>
    <br style="clear: both">
   <button style="padding: 10px; background: #0094FF; border: 2px solid #0094FF; color: white; font-size: 15px; font-weight: 900; width: auto;" class="fa fa-btc"> money</button>
  <button style="padding: 10px; background: #FF2D2D; border: 2px solid #FF2D2D; color: white; font-size: 15px; font-weight: 900; width: auto;">cancel</button>
</div>

<!-- upload_profile -->
<div style="display: none;" class="box_profile" style="display: none;" id="box_profile">
  <button style="background: none; border: none; text-align: center; font-size: 30px; float: right; width: 10%;
       " class="fa fa-times" onclick="profile()"></button>
      
      <p style="text-align: left; float: left; font-size: 20px; padding: 10px" class="fa fa-user-circle-o"> Upload profile</p>
      <br>
      <br style="clear: both">
  <img style="height: 200px; width: 200px; border-radius: 150px;" src='<?php echo $_SESSION["image"] ?>'>
   <br>
   <br>
  <label for="image">
    <li style="width: auto; background: #009CFF; padding: 10px; color: white; border-radius: 10px;font-size: 15px;" class="fa fa-upload"> upload profile new</li>
  </label>
  <input style="display: none; visibility: none;" name="image" id="image" type="file">
    <button style="padding: 10px; background: #FF2D2D; border: 2px solid #FF2D2D; color: white; font-size: 15px; font-weight: 900; width: auto; border-radius: 10px;">cancel</button>
</div>




   <!-- menu -->
   <div class="box_menu">
    <a style="float: left; font-weight: 900" class="fa fa-cogs"> Setting</a>
     <br>
     <?php
     if (isset($_SESSION["username"])) {
     	$path = explode("/", $_SESSION["image"]); 
     if (empty($path[0])) {
     	unset($path[0]);
     }
     
     if ($path[0] === "profile_image") {
           $path[0] = "profile avatar(chaos)";
         }
     if ($path[0] === "profile_chaos_image") {
           $path[0] = "profile image (user)";
         } else {
         	$path[0] = "choose image avatar(chaos)";
         }
          
     echo '
  <button class="fa fa-vcard" onclick="box_user()"> user information</button>
  <br>
  <button class="fa fa-user-circle-o" onclick="profile()"> profile
              </button>
  <br>
  	<button onclick="cargo()" class="fa fa-suitcase"> cargo</button>
   <br>
<select id="select-work" class="work-select" onclick="profile_chaos()">
	<option class="work-option" value="">' . $path[0] . '</option>
   <option class="work-option" value="profile_chaos_image/image_hacker.jpeg">boy</option>
   <option class="work-option" value="profile_chaos_image/image_go.jpeg">go</option>
   <option class="work-option" value="profile_chaos_image/image_hacker2.png">hacker</option>
</select> 
<div id="show"></div>
  <br>
     <button class="fa fa-bell"> warn</button>
     <br>
     <button class="fa fa-shopping-basket"> basket</button>
     <br>
   <a href="reset_password.php"><button class="fa fa-key"> reset password</button></a>
   <br>
   <button class="fa fa-book"> use my website</button>
      <br>
  <button class="fa fa-user-secret"> show developer chaos</button>
   <br>
  <form method="post"><button class="fa fa-sign-in" name="logout"> logout</button></form>
  <br>
  <p style="clear: both;"><br></p>
  <div style="float: left;"><p class="fa fa-btc"></p><a class="profix"> Payment method</a></div>
    <p style="clear: both;"></p>
  <div class="box-true">
  <img class="truemoney" src="image_shop/images (16).png">
  <p class="truemoney-x">true money</p>
  </div>
  ';
  } else {
  	echo '
<a href="register.php"><button class="fa fa-user-plus"> register</button></a>
<br>
<a href="login.php"><button class="fa fa-sign-in"> login</button></a>
';
  }
  
  ?>
  <br>
  <p class="profix">background</p>
    <div style="padding: 10px; width: 350px;" class="box-true">
      <p style="float: left;">background</p>
      <p style="float: right; font-size: 30px" class="fa fa-toggle-on"></p>
      <br>
    </div>
</div>
<br style="clear: both">
<br>
<br>
<br>
<br>
<div class="br_x">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>
<div class="top">
    <a href="shop.php"><li class="fa fa-shopping-cart"><p>shop</p></li></a>
      <a href="#"><li class="fa fa-book"><p>use</p></li></a>
      <a href="warn.php"> <li class="fa fa-bell"><p>warn</p></li></a>
      <a href="basket.php"> <li class="fa fa-shopping-basket"><p>basket</p></li></a>
    <a href="#"><li style="
    color: #FF5800;
    " class="fa fa-user-circle"><p>profile</p></li></a>
</div>


<style>

body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  margin: 0;
}

.modal_fade {
   display: none;
   position:fixed;
   background: black;
   padding: 10px;
   backdrop-filter: blur(5px);
   background-color: rgba(255, 255, 255, 0.4);
   box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
}

.box_menu {
  float: right;
  margin-top: 25%;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}

.box_user {
  position:fixed;
  background: black;
  padding: 10px;
  background: white;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  margin-top: 25%;
  margin-left: 10%;
}

.box_profile {
  position:fixed;
  background: black;
  padding: 10px;
  background: white;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  margin-top: 25%;
  margin-left: 20%;
}

.box_user img {
  float: left;
}

.br { 
  padding-top: 10%;
}

.box_user p {
  float: left;
  
}

.success {
	background: #00D40C;
    padding: 10px;
    color: white;
    text-align: center;
    border: 2px solid #00D40C;
    font-weight: 900;
    font-size: 15px;
    width: 97.5%;
    border-radius: 2px;
}

.error {
    background: #FF5151;
    padding: 10px;
    color: white;
    text-align: center;
    border: 2px solid #FF3434;
    font-weight: 900;
    font-size: 15px;
    width: 97.5%;
    border-radius: 2px;
}

    .preview {
        overflow: hidden;
        width: 150px; 
        height: 160px;
        margin: 10px;
        border: 1px solid red;
    }
    
    .modal-lg {
        max-width: 1000px;
        height: 100%;
    }


.box {
  width: 95%;
  padding: 10px;
  text-align: center;
}


.profile_xy {
  float: left;
  margin-top: 30%;
  margin-left: 5%;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  padding: 20px;
  border-radius: 10px;
}

.box button {
  background: #FFFFFF;
  color: #000000;
  border: 1px solid #B7B7B7;
  text-align: left;
  padding: 10px;
  width: 370px;
}

button {
  background: #FFFFFF;
}

.box img {
  height: 200px;
  width: 200px;
  border-radius: 150px;
  padding: 5px;
}

.box .truemoney {
  height: 40px;
  width: 40px;
  float: left;
}

.box .truemoney-x {
  font-size: 15px;
  padding: 17px;
  font-weight: 900;
  text-align: left;
}

.box .box-true {
  border: 1px solid #B7B7B7;
  width: 368px;
}

.box .profix {
  color: #000000;
  padding: 2px;
  font-size: 15px;
  font-weight: 900;
  text-align: left;
}

.box select {
  background: #FFFFFF;
  color: black;
  padding: 10px;
  width: 370px;
  height: auto;
  border-radius: 0;
  float: left;
}

.box .user {
  font-weight: 900;
  font-size: 20px;
}

.box p {
  font-size: 20px;
}

  .profile {
    background: black;
    color: #DFDFE1;
    font-size: 20px;
    padding: 20px;
  }
  
   .top {
    color: #FFFFFF;
    position:fixed;
    left:0px;
    bottom:0px;
    width: 100%;
    background: white;
    padding-top: 10px;
    display: flex;
    justify-content: space-around;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  }
  
.top li:hover {
  color: #FF5800;
}
 .top p {
  padding-left: 20px;
  color: #646465;
  margin: auto;
  text-align: center;
  padding: 20px;
  font-size: 20px;
}
.top li {
  color: #333434;
  margin: auto;
  text-align: center;
  font-size: 30px;
}


.cargo {
 display: none;
 position:fixed;
 background: black;
 padding: 10px;
 backdrop-filter: blur(5px);
 background: white;
 box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
 margin: auto;
 width: 380px;
 margin-top: 35%;
 height: 400px;
 margin-left: 5%;
}

.cargo #logo {
  font-size: 20px;
  padding: 10px;
}

.boxio {
  border-bottom: 1px solid #CACACA;
  padding: 5px;
  display: flex;
  justify-content: space-around;
}

.boxio img {
  height: 50px;
  width: 50px;
  margin-top: -10px;
} 

.boxio .boxio_name {
 text-overflow: ellipsis;
 overflow: hidden;
 width: 70px;
 text-align: center;
}

.show_archive {
  border-bottom: 1px solid #EBEBEB; 
  font-weight: 900;   
  display: flex;
  justify-content: space-around;
}

.show_archive p {
  padding: 10px;
  width: 50px;
}

.boxio #archive {
  background: #008BFF;
  border: 1px solid #1D98FF;
  padding: 10px;
  color: white;
  box-shadow: 0px 8px 16px 0px #A5C0FF;
  border-radius: 5px;
  margin-top: -5px;
}

.boxio #set {
  background: #FF1D1D;
  border: 1px solid #FF1D1D;
  padding: 10px;
  color: white;
  box-shadow: 0px 8px 16px 0px #FFA5A5;
  border-radius: 5px;
  margin-top: -5px;
}

@media screen and (max-width: 400px) {
    .top p {
    font-size: 15px;
  }
 
 .cargo {
 	margin-left: 0%;
 	}
 
  .error {
  	width: 94%;
  }
  
 .success {
 	width: 94%;
 }
  
  .top li {
    font-size: 25px;
  }
   .profile a {
     font-size: 15px;
  }
  
   .profile p {
     font-size: 15px;
     padding: 5px;
   }
   
   .box_user p {
     clear: both;
     float: left;
     padding: 5px;
   }
   .br {
     padding: 0;
   }
   
   #user {
     display: none;
   }
   
   .box_menu {
     float: none;
     box-shadow: none;
     margin-top: 0;
   }
   
   .profile_xy {
     float: none;
     box-shadow: none;
     margin-top: 0;
     margin-left: 0;
     margin: auto;
     padding: 0;
   }
   
   .br_x {
     display: none;
   }
   
   .box {
     width: 95%;
     padding: 5px;
     text-align: none;
   }
   
   .box img {
     height: 150px;
     width: 150px;
   }
      
   .box_profile {
     margin-left: 0;
     margin-top: 0;
     width: 90%;
   }
   
   .box_user {
     margin-left: 5px;
     margin-top: -150px;
     width: 90%;
   }
   
   #box_user_p {
     padding: 0px;
     margin-top: -50px;
   }

 }

</style>

<script>

  function box_user() {
    if (document.getElementById("box_user").style.display === "none") {
         	document.getElementById("box_user").style.display = "block";
    } else {
    	document.getElementById("box_user").style.display = "none";
      }
 }

  function profile() {
    if (document.getElementById("box_profile").style.display === "none") {
         	document.getElementById("box_profile").style.display = "block";
    } else {
    	document.getElementById("box_profile").style.display = "none";
      }
      
    console.log ("profile")
    $(document).ready(function() {
      $image_crop = $('#image_demo').croppie({
        enableExif: true,
        viewport: {
          width: 200,
          height: 200,
          type: 'circle' //circle
        },
        boundary: {
          width: 300,
          height: 300
        }
      });
      $('#image').on('change', function() {
        document.getElementById("box_profile").style.display = "none";
        var reader = new FileReader();
        reader.onload = function(event) {
          $image_crop.croppie('bind', {
            url: event.target.result
          })
        }
        reader.readAsDataURL(this.files[0]);
        $('#uploadimage').show();
      });
      $('.crop_image').click(function(event) {
        $image_crop.croppie('result', {
          type: 'canvas',
          size: 'viewport'
        }).then(function(response) {
          $.ajax({
            url: "upload_crop_profile/upload_image.php",
            type: "POST",
            data: { "image": response },
            success: function(data)
            {
              $('#uploaded_image').html(data)
            }
          });
        })
      });
    });
  }
  
  function profile_chaos() {
    $('.work-select').change(function() {
        $.ajax({
            method: "POST",
            url: "upload_crop_profile/upload_image.php",
            data: {
                image_profile: $(this).val()
            },
            success: function(data){
                $("#show").html(data);
            }
        });
    });
};
    
  function cargo() {
         	if (document.getElementById("cargo").style.display === "none") {
         	document.getElementById("cargo").style.display = "block";
         } else {
         	document.getElementById("cargo").style.display = "none";
         }
   }
  
</script>

</body>
</html>
