<?php
session_start();
require 'server/server.php';
$s = $_SESSION;
$pass_cargo = $s["cargo_pass"];
$sql = mysqli_query($conn, "SELECT * FROM deal where pass_cargo='$pass_cargo' ");
$sql = mysqli_fetch_array($sql);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

  <title>cargo</title>
</head>
<body>


<div class="image_1">
<p onclick="openxx()" id="open" class="glyphicon glyphicon-resize-full"></p>

<img id="logoimage" class="logoimage" onclick="image()" src="image_cargo/<?php echo $s["cargo_image"]; ?>">

<div id="showimage">
<br>
<img onclick="setimage('<?php echo 'image_cargo/' . $s["cargo_image"]; ?>')" class="imagexbox" src="image_cargo/<?php echo $s["cargo_image"]; ?>">
<br><br>
</div>
</div>

<div class="box">
<p class="logo">AK47
</p>
<p class="not">Not Details</p>
 <button class="image">Image</button>
 <br><br>
</div>

<div id="box2" class="box2">
  <center>
    
  <img class="setssing" src="image_shop/sess.gif">
  </center>
  <div style="
  position: absolute;
  width: 95%;
  text-align: center;
  margin-top: -40px;
  
  ">
  <p class="center">ใบเสร็จสินค้า</p>
  </div>
  <table>
  <tr>
  <th>
    รหัสสินค้า
  </th>
  <td>
    <?php echo $s["cargo_pass"]; ?>
  </td>
  </tr>
   <tr>
     <th>
       ชื่อสินค้า
     </th>
     <td>
       <?php echo $s["cargo_name"]; ?>
     </td>
   </tr>
         <tr>
           <th>
             ราคา
           </th>
           <td>
             <?php echo $s["cargo_num"]; ?>
           </td>
         </tr>
      <tr>
        <th>
          รายระเอียดเพิ่มเติม
        </th>
        <td> 
        <?php echo $s["cargo_text"]; ?>
        </td>
      </tr>
            <tr>
              <th>
                เวลาสั่งซื้อ
              </th>
              <td>
                Day: <?php echo $s["cargo_day"]; ?> <br>
                Time: <?php echo $s["cargo_time"]; ?>
              </td>
            </tr>
            <tr>
              <th>
                โหลดไฟล์
              </th>
              <td>
                <a class="download" href="cargo_back_end/file_cargo/<?php echo $s["cargo_file"]; ?>" download>Download File</a>
              </td>
            </tr>
            <tr>
      <th>
          อีเมล์ของผู้ซื้อ
        </th>
        <td> 
        <?php echo $sql["user_cargo"]; ?>
        </td>
             </tr>
                  <tr>
                    <th>
                      ยอดเงินคงเหลือ
                    </th>
                    <td>
                      <?php echo $s["cargo_money"] . ".00"; ?>
                    </td>
                  </tr>
  </table>
  <a href="shop.php">ย้อนกลับหน้าหลัก</a>
</div>

<p id="top">
  <br>
</p>


<style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    width: 100%;
  }

  * {
    margin: 0;
  }

  .image_1 .logoimage {
    height: 480px;
  }
  
  .image_1 {
   background: #121212;
   text-align: center;
  }
  
  .box {
    font-size: 20px;
    font-weight: 900;
    padding: 10px;
  }
  
  .box2 {
    padding: 10px;
    transition-duration: 1.5s;
    box-shadow: none;
    margin-left: -300%;
  }
  
    @media screen and (max-width: 400px) {
      
  .box2 .center {
    font-weight: 900;
    font-size: 17px;
    color: black;
    margin-left: 5px;
  }
 }
    .box2 .center {
      font-weight: 900;
      font-size: 17px;
      color: black;
      margin-left: 10px;
    }
    
  .setssing {
    height: 170px;
  }
  
  .not {
    color: #7A7A7A;
    font-weight: normal;
  }
  
  .box2 th, td {
  width: 400px;
  border: 1px solid #D6D6D6;
  border-left: none;
  border-right: none;
  border-bottom: none;
  padding: 10px;
}

 .box2 th {
   border-right: 2px solid black;
   font-weight: lighter;
 }
 
 .box2 td {
   padding-left: 10px;
   padding-left: 5%;
 }
 
 .box2 .download {
   padding: 7px;
   background: #0362DE;
   color: #FFFFFF;
   border: 2px solid #0057C9;
   font-weight: 900;
 }
 
 .image {
   background: #8602CB;
   color: white;
   font-weight: 900;
   padding: 7px;
   border: 2px solid #8300C9;
   width: auto;
 }

 #open {
   color: #FFFFFF;
   margin-left: 90%;
   margin-top: 10px;
   font-size: 20px;
   position: absolute;
   display: none;
 }

table {
  margin: auto;
}

.imagexbox {
  height: 100px;
  margin-left: 10px;
  margin-top: 10px;
  border-radius: 5px;
}

.image_1 #left, #rigth {
  font-size: 45px;
  position: absolute;
}

#showimage {
  display: none;
}

</style>

<script>
  
document.getElementById("box2").style.marginLeft = "0px"; 


  function image() {
    var x = document.getElementById("open").style.display;
    
    if (x === "none") {
         document.getElementById("open").style.display = "block";
      document.getElementById("showimage").style.display = "block";
       console.log ("*")
    } else {
      document.getElementById("open").style.display = "none";
      document.getElementById("showimage").style.display = "none";
    }
    
  }
  
  function openxx() {
    open (document.getElementsByClassName("logoimage")[0].src);
  }
  

  function setimage(imagexname) {
    document.getElementById("logoimage").src = imagexname;
  }

</script>
  <script>location.href = "#top";</script>
</body>
</html>
