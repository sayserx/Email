<?php

class image_x {
	
	function image($image) {
		$image_array_1 = explode(";", $image);
        $image_array_2 = explode(",", $image_array_1[1]);
        $image_x = base64_decode($image_array_2[1]);
        $imageName = time() . '.png';
        file_put_contents( '../profile_image/'.$imageName, $image_x);
        return '/profile_image/'.$imageName;
	}
	
	function profile_info_database($conn, $id, $image_path) {
		mysqli_query($conn, "UPDATE user SET id = '".$id."' , image_path = '".$image_path."' ");
	}
	
}

$image = new image_x();