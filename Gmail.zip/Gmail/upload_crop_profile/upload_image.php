<?php
session_start();
require '../server/server.php';
require 'image_oop.php';
require '../register_gmail/register_oop.php';

if (isset($_POST["image"])) {
$data = $_POST["image"];
$user = $register->email($conn, $_SESSION["username"], $_SESSION["password"], 'username');
if (isset($user)) {
	$profile_image = $image->image($data);
    $image->profile_info_database($conn, $user["id"], $profile_image);
	$_SESSION["image"] = $profile_image;
	echo '<script>document.getElementById("uploadimage").style.display = "none";location.replace("profile.php");</script>';
  }
}

if (isset($_POST["image_profile"])) {
	$path_image = $_POST["image_profile"];
    if (!empty($path_image)) {
     	$user = $register->email($conn, $_SESSION["username"], $_SESSION["password"], 'username');
         if (isset($user)) {
         	$image->profile_info_database($conn, $user["id"], $path_image);
             $_SESSION["image"] = $path_image;
             $_SESSION["success"] = "Upload Image Success";
	         echo '<script>location.replace("profile.php");</script>';
         } else {
         	$_SESSION["error"] = "Error Please inform admin";
             echo '<script>location.replace("profile.php");</script>';
         }
  }
}