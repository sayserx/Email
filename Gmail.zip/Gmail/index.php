<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="theme-color" content="black">
  <title>shop</title>
</head>
<body>
  

 <div class="menu">
<marquee direction="left">website chaos auto service system</marquee>
<div class="topnav" id="myTopnav">
  <img class="active" src="image_shop/orca-image-1885319496.jpeg">
  <a></a>
  <a class="fa fa-cart-arrow-down" style="background: #F90000;" href="#news"> Shop</a>
  <a href="login.html" class="fa fa-user" href="#contact"> Login</a>
  <a href="index.html" class="fa fa-user-plus" href="#about"> Register</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i style="font-size: px;" class="fa fa-bars"></i>
  </a>
</div>
 </div>
<br>


<div class="box">
<div class="box1">
<form action="shop.php" method="post">
  <button><img class="image_x" src="image_shop/game.jpg"></button></form>

<form action="shop.php" method="post">
<button><img class="image_x" src="image_shop/20221006_201000.jpg"></button>
</form>
</div>
<br>
<div class="box1">
<form action="shop.php" method="post">
  <button><img class="image_x" src="image_shop/20221007_214131.jpg"></button></form>

<form action="shop.php" method="post">
  <button><img class="image_x" src="image_shop/x.jpg"></button></form>
</div>

</div>

<div class="box1"><p></p><br><br><p></p></div>
<p style="padding: 10px;"></p>

<div class="top">
  <p class="tex" style="border-bottom: 2px solid #30D9FF; ">About chaos</p>
  <br>
  <p class="fa fa-facebook-square"> Anarchist Federation Chaos</p>
  <br>
  <p class="fa fa-envelope"> ChaosMain.47@gmail.com</p>
  <br>
  <p class="fa fa-github"> Chaos</p>
  <br>
  <p class="topx">Copyright © Chaos-Shop</p>
</div>

<style>
  * {
    margin: 0;
  }
  body {
   font-family: Arial, Helvetica, sans-serif;
  }
  marquee {
    background: black; 
    color: #FF6060;
    font-family: Arial, Helvetica, sans-serif;
    padding: 10px;
    border-bottom: 1px solid #606060;
  }
  .topnav {
    background-color: #000000;
    overflow: hidden;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  }
  
.box1 {
  width: 200px;
  height: 240px;
  display: flex;

}

.box {
  margin-top: 50%;
  margin-left: 30%;
}

    .tex {
      width: 300px;
    }
    
.top {
  margin: auto;
  background: black;
  color: white;
  padding: 10px;
  position:fixed;
  left:0px;
  bottom:0px;
  width:100%;
  border-radius: 5px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
}


button {
  background: none;
  border: none;
  transition-duration: 1s;
  outline: none;
}

button:hover {
  margin-top: -10px;
}

.top p {
  padding: 5px;
  font-size: 15px;
}

.topx {
  background: black;
  color: #FFFFFF;
  border-top: 2px solid #B4B4B4;
  text-align: left;
}

.image_x {
  height: 250px;
  width: 170px;
  border-radius: 5px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
}

  .topnav a {
    float: left;
    display: block;
    color: #FFFFFF;
    text-align: center;
    padding: 17px;
    text-decoration: none;
    font-size: 15px;
    border-bottom: 4px solid black;
    transition-duration: 1.5s;
  }

  .topnav a:hover {
    background-color: #FF0000;
    color: #FFFFFF;
    border-bottom: 5px solid black;
    margin: 5px;
  }
  
  .topnav .active {
    float: left;
    height: 65px;
    margin-top: -10px;
    transition-duration: 1.5s;
  }
  
  .menu {
    background: black;
  }
  
  .active:hover {
    border-bottom: 2px solid #FF0000;
  }

  .topnav .icon {
    display: none;
  }
  @media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  
  .topnav a.icon {
    float: right;
    display: block;
    padding-top: 20px;
    margin: 0;
    border-bottom: 4px solid black;
  }
  
  .topnav .active {
    float: none;
  }
   
  .top {
    border-radius: 0;
    margin-top: 0;
  }
  
  .top p {
    font-size: 17px;
  }
  
  .topx {
    text-align: center;
  }
  
      .tex {
        width: 200px;
      }
      
  .box {
    margin-top: 0;
    margin-left: 0;
    padding: 10px;
  }
  
}
  @media screen and (max-width: 360px) {
    .image_x {
      width: 155px;
    }
    .top p {
      font-size: 17px;
    }
    .tex {
      width: 200px;
    }
      .topnav a {
        font-size: 15px;
      }
  }
  
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav a {
    font-size: 20px;
  }
}
</style>

<script>
  function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
</script>

</body>
</html>
